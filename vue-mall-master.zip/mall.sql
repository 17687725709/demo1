/*
Navicat MySQL Data Transfer

Source Server         : hhh
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : mall

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2021-06-07 18:14:46
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL,
  `name` varchar(64) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES ('1', 'admin', 'hh', '1234');

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `goodsId` bigint(20) NOT NULL,
  `goodsDetailId` bigint(20) NOT NULL,
  `orderId` bigint(20) NOT NULL,
  `content` varchar(500) DEFAULT NULL,
  `score` int(11) NOT NULL,
  `createtime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of comments
-- ----------------------------
INSERT INTO `comments` VALUES ('1', '4', '3', '3', '11', '好看', '100', '2021-04-23');
INSERT INTO `comments` VALUES ('2', '9', '17', '38', '31', 'wewe', '100', '2021-05-09');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `typeId` bigint(20) NOT NULL,
  `img` varchar(500) DEFAULT NULL,
  `desc` text,
  `updatetime` date NOT NULL,
  `createtime` date NOT NULL,
  `imgs` varchar(500) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('8', '蓝月亮 亮白增艳洗衣液（自然清香）3kg/瓶', '4', 'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1401801138,2892361402&fm=26&gp=0.jpg', '买二送一', '2021-04-27', '2021-04-27', 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=4053890594,2233877437&fm=26&gp=0.jpg', '蓝月亮品牌创立于1992年，是中国领先的以消费者为核心、以创新为驱动力的家庭清洁解决方案提供商。\r\n我们的愿景：让每一个家庭生活在蓝月亮的世界里，洁净、健康、舒适、体面、快乐。\r\n我们的使命：提供卓越产品、极致服务、专业咨询，让消费者洁净无忧。\r\n我们的价值观：为用户，更卓越。');
INSERT INTO `goods` VALUES ('11', '韩国扎染渐变刺绣短袖T恤女情侣装百搭小清新美式复古半袖2021潮', '2', 'https://img.alicdn.com/imgextra/i3/2208317011083/O1CN014dkY5C1Js3bNLj0hR_!!0-item_pic.jpg_430x430q90.jpg', '潮牌', '2021-04-27', '2021-04-27', 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3002514727,3483869810&fm=224&gp=0.jpg', 'ins超火扎染短袖T恤女2021新款韩版bf原宿风学生宽松chic半袖上衣');
INSERT INTO `goods` VALUES ('12', '纯棉白色短袖t恤女夏季新款韩版修身圆领T桖上衣显瘦打底体恤小衫', '2', 'https://gd3.alicdn.com/imgextra/i3/2209740499459/O1CN01t5LHPX2JkH3B1gnJI_!!2209740499459.jpg_400x400.jpg', '', '2021-04-27', '2021-04-27', 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1461292522,192158677&fm=26&gp=0.jpg', '面料柔软舒适 比一般的面料厚实，非常舒服，很满意，喜欢这种款的衣服。');
INSERT INTO `goods` VALUES ('14', '法式复古桔梗初恋森系超仙女甜美气质v领泡泡袖碎花雪纺连衣裙子', '2', 'https://img.alicdn.com/imgextra/i1/4132297574/O1CN01PrY7SX25owPBrk0dP_!!4132297574-0-lubanu-s.jpg_430x430q90.jpg', '', '2021-04-27', '2021-04-27', 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3341456148,2329625361&fm=224&gp=0.jpg', 'YUNWUXIN法式复古桔梗初恋森系超仙女甜美气质小清新收腰显瘦格子连衣裙子连衣裙 语娄秋季大码女装裙子复古中国风气质款遮肉卫衣裙连衣裙小清新穿搭潮2021连衣裙 语娄法式文');
INSERT INTO `goods` VALUES ('15', '韩国彩虹小兔夏日清凉小清新学生T恤宽松发泡工艺短袖女oversize', '2', 'https://img.alicdn.com/imgextra/i1/2208317011083/O1CN01oBHcY91Js3bqZ3TCM_!!0-item_pic.jpg_430x430q90.jpg', '', '2021-04-27', '2021-04-27', 'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1823678328,1840564410&fm=224&gp=0.jpg', '早春新款韩国潮牌W家的胸前字母刺绣oversize休闲情侣短袖T恤男女 即墨市晁琰服装店 6年 回头率: 60.5%');
INSERT INTO `goods` VALUES ('16', '小米11 Ultra 至尊 5G 骁龙888 2K AMOLED四曲面柔性屏 陶瓷工艺 12GB+256GB 黑色 游戏手机', '1', 'https://img12.360buyimg.com/n1/s450x450_jfs/t1/141178/11/17971/98076/60619c13Ea6e0669e/57dd81498c9031f7.jpg', '', '2021-04-27', '2021-04-27', 'https://ss0.baidu.com/7Po3dSag_xI4khGko9WTAnF6hhy/image/h%3D300/sign=79445facea1f4134ff37037e151e95c1/c995d143ad4bd113acaa757d4dafa40f4bfb051e.jpg', '1/1.12\"GN2大底,2K四微曲屏,120X超长焦,哈曼卡顿立体双扬.5000mAh超大电池');
INSERT INTO `goods` VALUES ('17', 'Apple iPhone 12 (A2404) 128GB 白色 支持移动联通电信5G 双卡双待手机', '1', 'https://img14.360buyimg.com/n1/s450x450_jfs/t1/161431/34/6440/40857/6023bc8aE934a06ef/0e2cc0a4df83ccc3.jpg', '', '2021-04-27', '2021-04-27', 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3554427548,1621463440&fm=26&gp=0.jpg', 'iPhone 12采用了直面边框设计，有黑色、白色、红色、绿色、蓝色、紫色六种配色。iPhone 12支持5G，搭载A14 Bionic芯片，双镜头后置摄像头系统。支持北斗导航。');
INSERT INTO `goods` VALUES ('18', '华为 HUAWEI Mate 30 Pro 5G 麒麟990 OLED环幕屏双4000万徕卡电影四摄8GB+256GB丹霞橙5G全网通游戏手机', '1', 'https://img11.360buyimg.com/n1/s450x450_jfs/t1/140388/4/19/125717/5eda2678E866e1150/395edf0dc989c686.jpg', '', '2021-04-27', '2021-04-27', 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1453842653,2392803826&fm=26&gp=0.jpg', 'HUAWEI Mate 30 Pro 5G 搭载麒麟 990 5G 芯片,5G 速度智领未来。配备超感光徕卡电影四摄,支持超高清夜摄、超高速摄影等电影级摄影功能。配备 40W 超级快充,27W 无线超级快充,让你片刻充能即可昂扬');
INSERT INTO `goods` VALUES ('19', 'vivo X60 Pro+ 12GB+256GB 深海蓝 5G手机 微云台双主摄 蔡司联合影像系统 5nm高通骁龙888旗舰芯片', '1', 'https://img10.360buyimg.com/n1/s450x450_jfs/t1/155837/2/6653/98664/6006947cEe52018c3/58768c19ab2f706a.jpg', '', '2021-04-27', '2021-04-27', 'https://ss3.baidu.com/-fo3dSag_xI4khGko9WTAnF6hhy/image/h%3D300/sign=e500c33be51fbe09035ec5145b610c30/00e93901213fb80ee5279d9a21d12f2eb838948d.jpg', '搭载蔡司联合影像系统,复原本真之美,带来专业级摄影体验;更有全场景智..');
INSERT INTO `goods` VALUES ('20', 'OPPO Find X3 Pro 骁龙888 5000万双主摄IMX766 10亿色臻彩屏 60倍显微镜 12+256GB 宇宙摩卡 5G拍照旗舰手机', '1', 'https://img13.360buyimg.com/n1/s450x450_jfs/t1/159384/4/15500/118624/605da676Ea4f72fff/a8579ed76df33f89.jpg', '', '2021-04-27', '2021-04-27', 'https://ss0.baidu.com/94o3dSag_xI4khGko9WTAnF6hhy/image/h%3D300/sign=8b05d94dd8fc1e17e2bf8a317a91f67c/42166d224f4a20a48e8f529c87529822730ed0dc.jpg', 'OPPOFindX3系列,搭载10亿色双主摄,10亿色臻彩屏,全链路色彩引擎;未来流线..');
INSERT INTO `goods` VALUES ('21', '【歌德老酒行】贵州茅台酒 飞天茅台 2015年 酱香型白酒 53度 500ml', '3', 'https://img14.360buyimg.com/n1/jfs/t1/166246/6/13753/155027/605c0827Ec3c4a975/e53a2c0d16e2849b.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('22', '雀巢（Nestle）醇品 餐后清咖 速溶 黑咖啡 无蔗糖 冲调饮品 盒装48包*1.8克（新老包装随机发货）坤坤同款', '3', 'https://img11.360buyimg.com/n1/jfs/t1/165366/39/20835/345287/608684c7Ee5f767b2/12087b0a28c1c71e.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('23', '【2021新茶上市】第一江南 茶叶绿茶 明前特级工艺龙井叶春茶纸包 钱塘特级龙井200g', '3', 'https://img10.360buyimg.com/n1/jfs/t1/163735/36/13424/159495/60555b58Eae6b325f/068ac0975e4d395c.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('24', '费列罗拉斐尔进口椰蓉糖果礼盒小白球女神专享表白礼物520礼物', '3', 'https://img11.360buyimg.com/n1/jfs/t1/185641/13/899/213858/608524a7Eee9f7a7c/9ee233ef8577753b.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('25', '【300 减200】良品铺子 夏威夷果120g 每日坚果干果 坚果炒货零食 奶油味休闲零食小吃', '3', 'https://img13.360buyimg.com/n1/jfs/t1/160070/2/19212/325756/607d9b61E0d5af3ce/fc4a50dd7ec99232.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('26', 'THERMOS膳魔师焖烧罐470ml高真空不锈钢保温饭盒保温桶SK-3000 PK 【京东专供】', '4', 'https://img14.360buyimg.com/n1/jfs/t1/127213/31/19273/65567/5fb64898E54236299/f959b194a75e4cfb.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('27', '博洋家纺全棉四件套纯棉简约夏季床品床笠套件1.8m双人被套床单床上用品 闻香（床单款） 1.8米/6英尺床', '4', 'https://img13.360buyimg.com/n1/jfs/t1/171649/2/6682/119598/6086e739Efd1c5fef/8a997e03fa15a8ea.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('28', '利快 多用途脏衣篮日本进口like-it洗衣篮杂物卫浴收纳篮整理筐 白色单个 大号27.7x45.5x39cm', '4', 'https://img11.360buyimg.com/n1/jfs/t1/168441/33/21254/250539/6086e65cEece0d387/d5804d12c4143643.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('29', '中国科幻基石丛书：三体全集+超新星纪元+球状闪电（套装共5册）', '5', 'https://img11.360buyimg.com/n1/g13/M00/0F/1A/rBEhVFJWgtQIAAAAABYy8ainCvkAAD_CwIhjcQAFjMJ922.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('30', '东野圭吾推理套装全套全集共4册 白夜行+恶意+解忧杂货店+嫌疑人X的献身 悬疑推理小说 新华书店书籍', '5', 'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1620631820,3744171776&fm=15&gp=0.jpg', '41516515616', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('31', '伊坂幸太郎：金色梦乡（新版）', '5', 'https://img12.360buyimg.com/n1/jfs/t1/164187/16/3110/184084/60052ac7Eca565f54/ef857bcf4c44e080.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('32', '月亮与六便士 完整插图珍藏版 世界名著文学小说', '5', 'https://img11.360buyimg.com/n1/jfs/t1/19237/14/12461/104726/5c984914Ef0f46001/c23f316c1f24db77.jpg', '', '2021-04-27', '2021-04-27', null, null);
INSERT INTO `goods` VALUES ('33', '尼罗河上的惨案+东方快车谋杀案', '5', 'https://img14.360buyimg.com/n1/jfs/t1/168380/2/10919/110236/6046de62Eda617817/eb31977fc0ae918c.jpg', '', '2021-04-27', '2021-04-27', null, null);

-- ----------------------------
-- Table structure for goodsdetails
-- ----------------------------
DROP TABLE IF EXISTS `goodsdetails`;
CREATE TABLE `goodsdetails` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `goodsId` bigint(20) NOT NULL,
  `specName` varchar(500) NOT NULL,
  `stockNum` int(11) NOT NULL DEFAULT '0',
  `unitPrice` float NOT NULL,
  `updatetime` date NOT NULL,
  `createtime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of goodsdetails
-- ----------------------------
INSERT INTO `goodsdetails` VALUES ('3', '3', 'S', '99', '60.5', '2021-04-23', '2021-04-23');
INSERT INTO `goodsdetails` VALUES ('8', '3', 'M', '100', '60.5', '2021-04-23', '2021-04-23');
INSERT INTO `goodsdetails` VALUES ('9', '3', 'L', '100', '60.5', '2021-04-23', '2021-04-23');
INSERT INTO `goodsdetails` VALUES ('10', '8', '薰衣草香 3kg', '0', '44.8', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('13', '11', 'S', '49', '38.4', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('15', '11', 'M', '54', '38.4', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('16', '11', ' L', '54', '38.4', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('17', '11', 'XL', '54', '38.4', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('18', '12', 'S', '0', '18.1', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('19', '12', 'M', '45', '18.14', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('20', '12', 'L', '4', '18.14', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('24', '14', 'S', '5', '69.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('25', '14', 'M', '5', '69.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('26', '14', 'L', '1', '69.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('27', '14', 'XL', '0', '69.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('28', '15', '默认', '2', '38.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('29', '15', 'M', '5', '38.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('30', '15', 'L', '45', '38.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('31', '15', 'XL', '5', '38.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('35', '16', '陶瓷黑 8GB+128GB', '59', '5999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('36', '16', '陶瓷白 16GB+256GB', '54', '7999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('37', '16', '大理石纹理特别版 8GB+128GB', '54', '6499', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('38', '17', '白色 8GB+126GB', '0', '6499', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('39', '17', '黑色 8GB+256GB', '85', '7499', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('40', '17', '灰色 8GB+256GB', '80', '7499', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('41', '17', '绿色 8GB+256GB', '25', '7299', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('42', '18', '星河银 8GB+256GB', '5', '6099', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('43', '18', '亮黑色 8GB+256GB', '14', '6099', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('44', '18', '罗兰紫', '24', '6099', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('45', '18', '翡翠冷', '16', '6099', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('46', '18', '青山黛', '30', '6099', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('47', '19', '深海蓝 16GB+256GB', '48', '5998', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('48', '19', '深海蓝 8GB+128GB', '40', '4998', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('49', '19', '经典橙 16GB+256GB', '58', '5998', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('50', '19', '经典橙 8GB+128GB', '20', '4998', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('51', '20', '镜黑 16GB+256GB', '59', '5999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('52', '20', '雾白 16GB+256GB', '45', '5999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('53', '20', '凝白 16GB+256GB', '52', '5999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('54', '20', '宇宙摩卡 16GB+256GB', '39', '5999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('55', '20', '镜黑 8GB+128GB', '42', '4999', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('56', '21', '单瓶装', '2', '3990', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('57', '21', '6 *整箱', '3', '6899', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('58', '22', '醇品黑咖 48包', '58', '48.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('59', '22', '醇品黑咖  200g', '50', '72.8', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('60', '22', '醇品黑咖  50g', '10', '20.8', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('61', '23', '钱塘特级龙井 200g', '56', '598', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('62', '23', '西湖龙井龙坞产区 250g', '23', '2198', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('63', '24', '费列罗拉斐尔进口椰蓉糖果礼盒', '26', '78', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('64', '25', '夏威夷果120g', '65', '31.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('65', '8', '自然清香 3kg', '40', '44.8', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('66', '8', '自然清香 3*4kg', '62', '179.2', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('67', '8', '薰衣草香 3*4kg', '62', '179.2', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('68', '26', 'SK-3000-470ml 粉色（京东专供）', '14', '168', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('69', '26', 'SK-3000-470ml 白色', '17', '168', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('70', '26', 'SK-3000-470ml 条纹红色', '45', '168', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('71', '26', 'SK-3000-470ml 天蓝色', '54', '168', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('72', '27', '悠然卉语', '44', '319', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('73', '27', '维尔娜', '52', '319', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('74', '27', '森林秘密', '51', '319', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('75', '27', '羽叶', '50', '319', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('76', '27', '麦洛斯', '61', '319', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('77', '28', '棕色单个', '15', '29.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('78', '28', '白色单个', '20', '29.9', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('79', '29', '三体套装（5册）', '158', '78.2', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('80', '29', '三体1：地球往事', '100', '20.6', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('81', '29', '三体2：黑暗森林', '99', '28.6', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('82', '29', '三体3：死神永生', '130', '20.3', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('83', '29', '三体X·观想之宙（典藏版）', '214', '12.1', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('84', '29', '「超新星纪元（全本珍藏版）」 无货', '111', '15', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('85', '30', '默认', '21', '108', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('86', '31', '默认', '49', '34.5', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('87', '32', '默认', '45', '19.8', '2021-04-27', '2021-04-27');
INSERT INTO `goodsdetails` VALUES ('88', '33', '默认', '54', '64.4', '2021-04-27', '2021-04-27');

-- ----------------------------
-- Table structure for messages
-- ----------------------------
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `goodsId` bigint(20) NOT NULL,
  `content` varchar(500) NOT NULL,
  `state` enum('0','1') NOT NULL DEFAULT '0',
  `createtime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of messages
-- ----------------------------
INSERT INTO `messages` VALUES ('3', '5', '1', '2121', '1', '2021-04-23');
INSERT INTO `messages` VALUES ('4', '5', '1', 'hh', '1', '2021-04-23');
INSERT INTO `messages` VALUES ('5', '5', '1', 'qq', '0', '2021-04-23');
INSERT INTO `messages` VALUES ('6', '12', '8', 'das', '0', '2021-06-06');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `goodsDetailId` bigint(20) NOT NULL,
  `goodsNum` int(11) NOT NULL,
  `amount` float NOT NULL,
  `state` enum('0','1','2','3') NOT NULL DEFAULT '0',
  `createtime` date NOT NULL,
  `updatetime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('46', '12', '38', '4', '25996', '1', '2021-06-01', '2021-06-01');

-- ----------------------------
-- Table structure for replies
-- ----------------------------
DROP TABLE IF EXISTS `replies`;
CREATE TABLE `replies` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `messageId` bigint(20) NOT NULL,
  `content` varchar(500) NOT NULL,
  `createtime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of replies
-- ----------------------------
INSERT INTO `replies` VALUES ('1', '3', 'zhengpin', '2021-04-23');
INSERT INTO `replies` VALUES ('2', '4', '哈哈', '2021-04-23');

-- ----------------------------
-- Table structure for types
-- ----------------------------
DROP TABLE IF EXISTS `types`;
CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of types
-- ----------------------------
INSERT INTO `types` VALUES ('1', '数码产品');
INSERT INTO `types` VALUES ('2', '时尚服装');
INSERT INTO `types` VALUES ('3', '食品饮料');
INSERT INTO `types` VALUES ('4', '日常用品');
INSERT INTO `types` VALUES ('5', '小说书刊');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(64) DEFAULT NULL,
  `pwd` varchar(255) NOT NULL,
  `nickname` varchar(64) NOT NULL,
  `recipient` varchar(64) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `headimg` varchar(500) NOT NULL,
  `updatetime` date NOT NULL,
  `createtime` date NOT NULL,
  `sex` enum('0','1','2') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('12', '122@qq.com', '$2a$10$TSg5B/iC.bXrrRe8MWhfw.5MQF2dmkzSuqo84dDIqAN2x/ABH4tpK', '123', 'wudg', 'dasd', '13669663687', 'http://tvax4.sinaimg.cn/crop.0.0.480.480.180/768c39d5ly8fjje1d0teej20dc0dcq35.jpg', '2021-06-01', '2021-06-01', '1');
