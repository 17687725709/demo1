import * as types from './mutation-types';

/*export const setNewsCacheByType = function({commit},{type,data}){
	commit(types.SET_CACHE_NEWS,type,data)
}*/