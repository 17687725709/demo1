<template>
    <div class="FixedNav" :style="{width:width}">
        <slot name="navContent"></slot>
    </div>
</template>

<script>
import {getClientSize} from '../util/util';
export default {
  name: 'FixedNav',
  props:{
  },
  data(){
    return{
      width:''
    }
  },
  mounted(){
    this.searchFormWidth(); // 组件初始化的时候不会触发onresize事件，这里强制执行一次
    	    window.onresize = () => {
    	      if(!this.timer){ // 使用节流机制，降低函数被触发的频率
    	        this.timer = true;
    	        let that = this; // 匿名函数的执行环境具有全局性，为防止this丢失这里用that变量保存一下
    	        setTimeout(function(){
    	          that.searchFormWidth();
    	          that.timer = false;
    	        },0)
    	      }
    	    }

  },
  destroyed() {
  		// 组件销毁后解绑事件
  		window.onresize = null;
  	},
  	methods:{
  		searchFormWidth() {
  	     this.width = getClientSize().width+'px';
  	    }
  	}
}
</script>

<style scoped lang="less">
@import "../assets/css/var.less";
.FixedNav{
  position: fixed;
  top: 0;
  left: 0;
  height: 64px;
  background-color: white;
  border-bottom: 1px solid @borderColor;
  animation: slideIn .3s;
  z-index: 10000;
}
@keyframes slideIn{
  from{
    top:-64px;
  }
  to{
    top:0px;
  }
}
</style>
