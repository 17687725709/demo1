<template>
  <div class="hot">
    <h2 style="width: 1090px;
    margin: 0 auto;
    margin-top: 50px;
    font-size: 26px;
    height: 32px;
    line-height: 32px;
    color: #333;
    font-weight: 400;
    text-align: center;">人气好物推荐，它们最受欢迎</h2>
    <div class="hot-goods">
      <h3 style="color: #666;
    font-size: 20px;
    line-height: 26px;
    height: 26px;
    text-align: center;
    margin: 23px 0 18px;
    font-weight: 400;">－编辑推荐－</h3>
    <ul class="result">
        <GoodsItem
          v-for="(item,index) in goodsList"
          :style="{marginRight: (index+1)%4===0?'0px':'25px'}"
          :key="+item.id"
          :id="item.id"
          :img="item.img"
          :name="item.name"
          :price="item.price"
        />
    </ul>
    </div>
  </div>
</template>

<script>
import GoodsItem from '../../components/GoodsItem';
import {getGoodsList} from '../../api/client';
export default{
  name:'hotgoods',
  components:{GoodsItem},
  data(){
    return {
      goodsList:''
    }
  },
  methods:{
    getList(){
      getGoodsList(1).then(res =>{
        this.goodsList = res
        console.log(res)
      })
    }
  },
  mounted(){
    this.getList()
  }
}
</script>

<style>
</style>
