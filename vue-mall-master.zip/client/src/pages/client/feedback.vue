<template>
  <div class="outerframe">
    <table class="innerframe">
      <tbody>
        <tr>
          <td class="td">
            <table class="welcome-table">
              <tbody>
                <tr>
                  <td class="survey-description">
                    <h1>Mall-用户反馈调查</h1>
                    <p class="surveydescription"></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td class="survey-welcome">
            <span class="surveywelcome">
              <span style="font-size: 14px;">尊敬的用户： &nbsp;</span>
              <p>
                <span style="font-size: 14px;">
                  您好！为了给您提供更好的服务，我们希望收集您使用
                  <strong style="color:rgb(255,0,0);">Mall</strong>
                  时的看法或建议。对您的配合和支持表示衷心感谢！
                </span>
              </p>
            </span>
          </td>
        </tr>
      </tbody>
    </table>


    <div class="group-0" align="center">
      <table class="group">
        <tbody>
          <tr>
            <td align="center">
              <br />
              <div class="left">
                <span class="group-name"></span>
              </div>
              <br />
              <div>
                <table class="question-wrapper">
                  <tbody>
                    <tr>
                      <td class="questiontext">
                        <span class="asterisk"></span>
                        <span class="qnumcode" style="display: none;"></span>
                        <span style="font-size:14px;">
                          <strong>
                            如果您在使用
                            <span style="color:rgb(255,0,0);">Mall首页</span>
                            时，有什么好或不好的地方，请大声说出来！我们会关注您的反馈，不断优化产品，为您提供更好的服务！
                          </strong>
                        </span>
                        <br>
                        <span class="questionhelp"></span>
                        <span class="questionhelp" id="vmsg_25068"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="survey-question-help">
                      </td>
                    </tr>
                    <tr>
                      <td class="answer">
                        <p class="question answer-item text-item  inputwidth-70">
                          <label for="answer889711X1018X25068" class="hide label">
                            <!-- 答案 -->
                          </label>
                          <textarea class="textarea  empty" alt="答案" rows="8" cols="70">
                            </textarea>
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="list-radio mandatory">
      <table class="question-wrapper" style="width: 75%;">
        <tbody>
          <tr>
            <td class="questiontext">
              <span class="asterisk">*</span><span class="qnumcode" style="display: none;"> </span><span style="font-size:14px;"><strong>您对<span
                    style="color:rgb(255,0,0);">Mall首页</span>的整体满意度如何？</strong></span><br><span class="questionhelp"></span>
              <span class="questionhelp" id="vmsg_25063"></span>
            </td>
          </tr>
          <tr>
            <td class="survey-question-help">
            </td>
          </tr>
          <tr>
            <td class="answer">
              <ul class="answers-list radio-list">
                <li id="javatbd889711X1018X250631" class="answer-item radio-item">
                  <input class="radio" type="radio" value="1" name="889711X1018X25063" id="answer889711X1018X250631"
                    onclick="if (document.getElementById('answer889711X1018X25063othertext') != null) document.getElementById('answer889711X1018X25063othertext').value='';checkconditions(this.value, this.name, this.type)">
                  <label for="answer889711X1018X250631" class="answertext"><span style="font-size:14px;">非常满意</span></label>
                </li>
                <li id="javatbd889711X1018X250632" class="answer-item radio-item">
                  <input class="radio" type="radio" value="2" name="889711X1018X25063" id="answer889711X1018X250632"
                    onclick="if (document.getElementById('answer889711X1018X25063othertext') != null) document.getElementById('answer889711X1018X25063othertext').value='';checkconditions(this.value, this.name, this.type)">
                  <label for="answer889711X1018X250632" class="answertext"><span style="font-size:14px;">满意</span></label>
                </li>
                <li id="javatbd889711X1018X250633" class="answer-item radio-item">
                  <input class="radio" type="radio" value="3" name="889711X1018X25063" id="answer889711X1018X250633"
                    onclick="if (document.getElementById('answer889711X1018X25063othertext') != null) document.getElementById('answer889711X1018X25063othertext').value='';checkconditions(this.value, this.name, this.type)">
                  <label for="answer889711X1018X250633" class="answertext"><span style="font-size:14px;">一般</span></label>
                </li>
                <li id="javatbd889711X1018X250634" class="answer-item radio-item">
                  <input class="radio" type="radio" value="4" name="889711X1018X25063" id="answer889711X1018X250634"
                    onclick="if (document.getElementById('answer889711X1018X25063othertext') != null) document.getElementById('answer889711X1018X25063othertext').value='';checkconditions(this.value, this.name, this.type)">
                  <label for="answer889711X1018X250634" class="answertext"><span style="font-size:14px;">不满意</span></label>
                </li>
                <li id="javatbd889711X1018X250635" class="answer-item radio-item">
                  <input class="radio" type="radio" value="5" name="889711X1018X25063" id="answer889711X1018X250635"
                    onclick="if (document.getElementById('answer889711X1018X25063othertext') != null) document.getElementById('answer889711X1018X25063othertext').value='';checkconditions(this.value, this.name, this.type)">
                  <label for="answer889711X1018X250635" class="answertext"><span style="font-size:14px;">非常不满意</span></label>
                </li>
              </ul>
              <input type="hidden" name="java889711X1018X25063" id="java889711X1018X25063" value="">
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="multiple-short-txt">
      <table class="question-wrapper" style="width: 75%;">
        <tbody>
          <tr>
            <td class="questiontext">
              <span class="asterisk"></span><span class="qnumcode" style="display: none;"> </span>
              <p>
                <span style="font-size:14px;"><strong>我们会不定期邀请用户参与体验交流。如果您有意参与，请填写如下信息，方便我们与您联系，谢谢！（信息仅作为内部资料绝不外泄）</strong></span></p>
              <br><span class="questionhelp"></span>
              <span class="questionhelp" id="vmsg_25064"></span>
            </td>
          </tr>
          <tr>
            <td class="survey-question-help">
            </td>
          </tr>
          <tr>
            <td class="answer">
              <ul class="subquestions-list questions-list text-list">
                <li id="javatbd889711X1019X250641" class="question-item answer-item text-item">
                  <label for="answer889711X1019X250641"><span style="font-size:14px;">您的称呼</span></label>
                  <span>
                    <input class="text  empty" type="text" size="20" placeholder="请输入姓名(必填)"
                      value="" onkeyup="checkconditions(this.value, this.name, this.type);">
                  </span>
                </li>
                <li id="javatbd889711X1019X250642" class="question-item answer-item text-item">
                  <label for="answer889711X1019X250642"><span style="font-size:14px;">手机号</span></label>
                  <span>
                    <input class="text  empty" type="text" size="20" placeholder="请输入联系电话(必填)" value="" onkeyup="checkconditions(this.value, this.name, this.type);">
                  </span>
                </li>
              </ul>
            </td>
          </tr>
        </tbody>
      </table>
    </div>


    <table class="navigator-table">
      <tbody>
        <tr>
          <td class="save-all">
            <span class="ui-button-text" @click="Submit">提交
            </span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
  export default {
    methods: {
      Submit(){
        swal( "谢谢反馈!");
      }
    }
  }
</script>

<style scoped lang="less">
  .outerframe {
    margin: 0;
    padding: 0;
  }

  .innerframe {
    width: 75%;
    text-align: center;
    border-collapse: separate;
    border-spacing: 1px;
    margin: 0 auto 0 auto;
  }

  .td {
    margin: 0;
    padding: 0;
  }

  .welcome-table {
    margin: 0 auto;
    width: 100%;
    padding-top: 1px;
    // font-family: Î¢ï¿½ï¿½ï¿½Åºï¿½;
  }

  .survey-description {
    border-bottom: 2px solid #e33b3d;
    color: #666;
    text-align: center;
    height: 43px;
    overflow: hidden;
    background: url(../../assets/img/cat.jpg) no-repeat 0 -10px;
    background-size: 165px auto;
  }

  .surveydescription {
    height: 0;
  }

  .survey-welcome {
    text-align: left;
    padding: 30px 65px 15px 35px;
  }

  .surveywelcome {
    line-height: 25px;
    text-align: left;
  }

  .group {
    width: 76%;
    margin: 0 0 2px 0;
    border: 0 none;
    border-collapse: collapse;
    background-color: #fff;
  }

  .group-name {
    font-size: 16px;
    // font-family: "";
    font-weight: bold;
  }

  .question-wrapper {
    width: 100%;
    margin: 0 auto 10px auto;
    border: 1px solid #cce8ff;
    padding: 1px;
    background-color: #FFFFFF
  }

  .questiontext {
    font-family: verdana;
    font-size: 12px;
    font-weight: bold;
    background-color: #EEF6FF;
    text-align: left;
    padding: 6px 10px;
  }

  .asterisk {
    color: red;
    font-size: 9px;
    font-family: verdana;
    margin-right: 5px;
  }

  .questionhelp {
    font-size: 10px;
    font-style: italic;
  }

  .survey-question-help {
    font-size: 10px;
    // background-color: #FFFDEE;
    padding-left: 1em;
    line-height: 24px;
    color: #999999;
    text-align: left;
  }

  .answer {
    padding: 11px 24px 16px 37px;
    text-align: left;
  }

  .question {
    margin-top: 10px;
    margin-bottom: 10px;
  }

  .textarea {
    margin-top: 10px;
    margin-bottom: 10px;
    margin-right: 10px;
    border: 1px solid;
  }

  .multiple-short-txt ul {
    display: table;
    padding: 0%;
    margin: 1em;
  }

  .multiple-short-txt ul li {
    display: table-row;
  }

  .multiple-short-txt ul li label {
    padding: 0.3em 1em 0% 0%;
    display: table-cell;
    vertical-align: baseline;
  }

  .navigator-table {
    width: 76%;
    margin: 0 0 0 12%;
    padding: 1px;
  }

  .save-all {
    text-align: left;
    width: 0%;
    background-color: #e2f3fd;
    // display: none;
  }

  .ui-button-text {
    display: block;
    line-height: 1.4;
    margin-left: 50%;
  }
</style>
