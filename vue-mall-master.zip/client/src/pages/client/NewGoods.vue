<template>
  <div class="newGoods">
    <header style="line-height: 1;
    padding-top: 50px;
    font-size: 34px;
    text-align: center;
    font-weight: 700;">全部新品</header>
    <ul style="margin-top: 30px;">
        <GoodsItem
          v-for="(item,index) in goodsList"
          :style="{marginRight: (index+1)%4===0?'0px':'25px'}"
          :key="+item.id"
          :id="item.id"
          :img="item.img"
          :name="item.name"
          :price="item.price" v-if="index < 12"/>
    </ul>
    </div>
  </div>
</template>

<script>
import {getGoodsList} from '../../api/client';
import GoodsItem from '../../components/GoodsItem';
export default{
  name:'newgoods',
  components:{GoodsItem},
  data(){
    return {
      goodsList:''
    }
  },
  methods:{
    getList(){
      getGoodsList(-1).then(res =>{
        this.goodsList = res
      })
    }
  },
  mounted(){
    this.getList()
  }
}
</script>

<style>
</style>
