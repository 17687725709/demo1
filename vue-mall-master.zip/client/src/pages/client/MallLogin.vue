<template>
  <div class="ClientLogin" :style="{width:width+'px',height:height+'px'}">
    <div class="content">
      <h3>农职Mall</h3>
      <div class="tag">
        <span @click="setIndex(0)" :class="{selected:curIndex===0}">登录</span>
        <span @click="setIndex(1)" :class="{selected:curIndex===1}">注册</span>
      </div>
      <div class="formBox" v-show="curIndex===0">
        <input ref="account" type="text" placeholder="账号" />
        <input ref="pwd" type="password" placeholder="密码" />
        <button @click="login">登录</button>
      </div>
      <div class="formBox" v-show="curIndex===1">
        <input ref="signName" type="text" placeholder="请输入昵称(必填)" v-model="names.name"  @focus="focus('name')"/><p style="color: #f91;height: 15px;font-size: small;">{{nameError}}</p>
        <input ref="signPwd" type="password" placeholder="请输入密码" v-model="names.password" @focus="focus('password')"/><p style="color: #f91;height: 15px;font-size: small;">{{pwError}}</p>
        <input ref="signPwds" type="password" placeholder="请确认密码" v-model="names.passwords"/><p style="color: #f91;height: 15px;font-size: small;">{{cpwError}}</p>
        <input ref="signEmail" type="text" placeholder="请输入注册的邮箱(必填)" v-model="names.email" @focus="focus('email')"/><p style="color: #f91;height: 15px;font-size: small;">{{emailError}}</p>
        <input ref="signPhone" type="text" placeholder="请输入联系电话(必填)" v-model="names.phone" @focus="focus('phone')"/><p style="color: #f91;height: 15px;font-size: small;">{{phoneError}}</p>
       <!-- <input ref="signSex" type="text" placeholder="请输入性别" v-model="<names></names>.sex" @change="sex" /> -->
        <select v-model="names.sex" name="fruit">
            <option value="none" selected disabled hidden>请选择性别</option>
            <option value="1">男</option>
            <option value="2">女</option>
            <option value="0">保密</option>
          </select>
		  <p style="color: #f91;height: 15px;font-size: small;">{{sexError}}</p>
        <input v-model="names.signRecipient" type="text" placeholder="请输入收件人姓名(必填)" @focus="focus('recipient')"/><p style="color: #f91;height: 15px;font-size: small;">{{receiptError}}</p>
        <input v-model="names.signAddress" type="text" placeholder="请输入收件地址(必填)" @focus="focus('address')"/><p style="color: #f91;height: 15px;font-size: small;">{{addressError}}</p>
        <button @click="signup">注册</button>
      </div>
    </div>
  </div>
</template>

<script>
  import {
    mapMutations
  } from 'vuex'
  import {
    getClientSize
  } from '../../util/util';
  import {
    login,
    signup
  } from '../../api/client';

  export default {
    name: 'ClientLogin',
    computed: {
      width() {
        return getClientSize().width;
      },
      height() {
        return getClientSize().height;
      },
    },
    data() {
      return {
        curIndex: 0,
        names: {
          name: "",
          email: "",
          password: "",
          phone: "",
          passwords: "",
          sex: "none",
		  signRecipient: "",
		  signAddress: ""
        },
        nameError:'',
		pwError:'',
        cpwError:'',
        emailError:'',
        phoneError:'',
		sexError:'',
        receiptError:'',
        addressError:''
      }
    },
    watch:{
      names:{
        handler(newVal){
        },
        deep:true,
        immediate: true,
      },
      /* 'names.name'(newVal){
        if(!newVal) {
          this.nameError = '昵称为必填项'
        }else{
			this.nameError = ''
		}
      }, */
      'names.phone'(newVal){
        if (!/^1[345789]\d{9}$/.test(newVal)) {
          this.phoneError = '请输入正确的手机号'
          // return;
        }else{
          this.phoneError = ' '
        }
      },
      'names.email'(newVal){
        var email = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/;
        if (!email.test(newVal)) {
          this.emailError = '请输入正确的邮箱'
          // return;
        }else{
          this.emailError = ''
        }
      },
      'names.passwords'(newVal){
        if (newVal != this.names.password) {
          this.cpwError = '两次输入的密码不一致'
          // return
        }else {
			  this.cpwError = ''
		}
      },
	  'names.sex'(newVal){
		  if(newVal != 'none') {
			  this.sexError = ''
		  }else {
			  this.sexError = '请选择性别'
		  }
	  }
	  /* 'name.signRecipient'(newVal){

	  } */
    },
    methods: {
      ...mapMutations({
        setClientName: 'SET_CLIENT_NAME',
        setClientToken: 'SET_CLIENT_TOKEN'
      }),
      setIndex(index) {
        if (index === this.curIndex) {
          return;
        }
        this.curIndex = index;
      },
      login() {
        const account = this.$refs.account.value;
        const pwd = this.$refs.pwd.value;
        const res = login({
          account: account,
          pwd: pwd
        });
        res
          .then((data) => {
            this.setClientName(data.name);
            this.setClientToken(data.token);
            this.$router.push('/');
          })
          .catch((e) => {
            swal("提示!", e, "error");
          })
      },
      signup() {
		if(this.names.name == ''){
			this.nameError = '请填写昵称'
		}
		if(this.names.password == ''){
			this.pwError = '请填写密码'
		}
		if(this.names.email == ''){
			this.emailError = '请填写邮箱'
		}
		if(this.names.phone == ''){
			this.phoneError = '请填写手机号'
		}
		if(this.names.sex == "none"){
			this.sexError = '请选择性别'
		}else{
			this.sexError = ''
		}
		if(this.names.signRecipient == ''){
			this.receiptError = '请填写收件人'
		}
		if(this.names.signAddress == ''){
			this.addressError = '请填写地址'
		}
		if([this.nameError, this.pwError, this.emailError, this.phoneError,this.sexError,this.receiptError,this.addressError].every(value=>{return value ==0})) {
			const res = signup({
			  email: this.$refs.signEmail.value,
			  nickname: this.$refs.signName.value,
			  pwd: this.$refs.signPwd.value,
			  recipient: this.names.signRecipient,
			  address: this.names.signAddress,
			  phone: this.$refs.signPhone.value,
			  sex: this.names.sex
			});
			res
			  .then((data) => {
			    this.setClientName(data.name);
			    this.setClientToken(data.token);
			    this.$router.push('/');
			  })
			  .catch((e) => {
			    swal("提示！", e, "warning");
			  })
		}
		/* else {
			const res = signup({
			  email: this.$refs.signEmail.value,
			  nickname: this.$refs.signName.value,
			  pwd: this.$refs.signPwd.value,
			  recipient: this.names.signRecipient,
			  address: this.names.signAddress,
			  phone: this.$refs.signPhone.value,
			  sex: this.names.sex
			});
			res
			  .then((data) => {
			    this.setClientName(data.name);
			    this.setClientToken(data.token);
			    this.$router.push('/');
			  })
			  .catch((e) => {
			    console.log(e)
			  })
		} */

      },
	  focus(a){
		var email = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/;
		a=='name'? this.nameError = ''
		:a=='password'?this.pwError=''
		:a=='email'?this.emailError=''
		:a=='phone'?this.phoneError=''
		:a=='recipient'?this.receiptError=''
		:a=='address'?this.addressError= '':''
	  }
     /* email() {
        var email = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/;
        if (!email.test(this.names.email)) {
          alert("请输入正确的邮箱");
          this.names.email = "";
          // return;
        }
      },
      phone() {
        if (!/^1[345789]\d{9}$/.test(this.names.phone)) {
          alert("请输入正确的手机号");
          // return;
        }
      },
      check() {
        var pwdConfirm = this.$refs.signPwds.value
        if (this.names.password != pwdConfirm) {
          alert('密码两次输入不一致')
          // return
        }
      }, */
      /* sex() {
        if (this.names.sex === "男") {
          this.names.sexs = 1
          return
          console.log(this.names.sexs)
        } else if (this.names.sex === "女") {
          this.names.sexs = 2
          return
        } else {
          alert('性别错误')
        }
      } */
    }
  }
</script>

<style scoped lang="less">
  @import "../../assets/css/var.less";

  .ClientLogin {
    background-color: @bgColor;
    position: relative;

    .content {
      width: 300px;
      position: absolute;
      top: 50%;
      left: 50%;
      margin-top: -260px;
      margin-left: -150px;
      text-align: center;
      overflow: hidden;

      h3 {
        color: @secondColor;
        font-size: 50px;
      }

      .tag {
        margin-top: 20px;
        color: @fontDefaultColor;
        margin-bottom: 20px;

        span {
          display: inline-block;
          width: 50px;
          text-align: center;
          margin: 0 10px;
          padding: 10px 0;
          cursor: pointer;
        }

        .selected {
          border-bottom: 2px solid @secondColor;
          color: @secondColor
        }
      }
      select {
         border-radius: 0;
         box-shadow: none;
         background: #fff;
         padding: 14px;
         width: 80%;
         border: 1px solid @borderColor;
      }
      input {
        border-radius: 0;
        box-shadow: none;
        background: #fff;
        padding: 14px;
        width: 80%;
        border: 1px solid @borderColor;
      }

      button {
        width: 90%;
        background: @secondColor;
        box-shadow: none;
        border: 0;
        border-radius: 3px;
        line-height: 41px;
        color: #fff;
        cursor: pointer;
        margin-top: 20px;
      }
    }
  }
</style>
