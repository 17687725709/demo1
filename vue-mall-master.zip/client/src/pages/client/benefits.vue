<template>
  <div class="body">
    <div id="rotary-table">
      <div class="award" v-for="(award,index) in awards" :key="award.id" :class="['award'+index,{'active': index==current}]">
        <p>{{award.name}}</p>

      </div>
      <div id="start-btn" @click="start">
        <h2>
          <span>开</span>
          <span>始</span>
        </h2>
      </div>
    </div>
  </div>
</template>
<script>
  import {
    mapState
  } from 'vuex';
  import {
    getGoodsInfo,
    getGoodsMsg,
    askGoodsMsg,
    addOrder,
    getComment,
    getGoodsList,
    getUserData
  } from '../../api/client';
  export default {
    name: 'raffle',
    data() {
      return {
        current: 0,
        awards: [{
            id: 1,
            name: '谢谢惠顾'
          },
          {
            id: 2,
            name: '满1000减25'
          },
          {
            id: 3,
            name: '谢谢惠顾'
          },
          {
            id: 4,
            name: '500积分'
          },
          {
            id: 5,
            name: '100积分'
          },
          {
            id: 6,
            name: '满500减10'
          },
          {
            id: 7,
            name: '50积分'
          },
          {
            id: 8,
            name: '谢谢惠顾'
          }
        ],
        speed: 200,
        diff: 15,
        award: {},
        time: 0,
        chou: '',
        na: ''
      };
    },
    computed: {
      ...mapState([
        'clientToken',
        'clientName'
      ]),
    },
    methods: {
      start() {
        if (!this.clientToken) {
          swal("提示！", "请先登录！", "warning");
          return;
        } else {
          // 开始抽奖
          this.chou = Math.round(Math.random() * 8);
          this.drawAward();
          this.time = Date.now();
          this.speed = 200;
          this.diff = 15;
          this.na = this.awards[this.chou - 1].name;
        }
      },
      drawAward() {
        // 请求接口, 这里我就模拟请求后的数据(请求时间为2s)
        setTimeout(() => {
          this.award = {
            id: this.chou,
            name: this.na,
          };
        }, 1000);
        this.move();
      },
      move() {
        window.timeout = setTimeout(() => {
          this.current++;
          if (this.current > 7) {
            this.current = 0;
          }
          if (this.award.id && (Date.now() - this.time) / 1000 > 2) {
            this.speed += this.diff;
            if ((Date.now() - this.time) / 1000 > 4 && this.award.id == this.awards[this.current].id) {
              clearTimeout(window.timeout);
              setTimeout(() => {
                alert('抽中了' + this.award.name);
              }, 0);
              return;
            }
          } else {
            this.speed -= this.diff;
          }
          this.move();
        }, this.speed);
      }
    }
  };
</script>

<style rel="stylesheet/less" lang="less">
  * {
    margin: 0;
    padding: 0;
    list-style: none;
    outline: none;
  }

  #rotary-table {
    margin: auto;
    width: 342px;
    height: 339px;
    position: relative;
    background-color: #ffa3a9;
    margin-top: 10%;

    .award {
      width: 90px;
      height: 96px;
      line-height: 96px;
      text-align: center;
      float: left;
      position: absolute;
      overflow: hidden;
      background-color: transparent;

      &.active {
        background-color: #ffe8bc;
      }

      &.award0 {
        top: 21px;
        left: 21px;
      }

      &.award1 {
        top: 21px;
        left: 125px;
      }

      &.award2 {
        top: 21px;
        right: 22px;
      }

      &.award3 {
        top: 126px;
        right: 22px;
      }

      &.award4 {
        bottom: 22.5px;
        right: 22px;
      }

      &.award5 {
        bottom: 22.5px;
        right: 125.5px;
      }

      &.award6 {
        bottom: 22.5px;
        left: 21px;
      }

      &.award7 {
        top: 126px;
        left: 21px;
      }
    }

    .award p {
      color: white;
    }

    #start-btn {
      position: absolute;
      top: 125px;
      left: 124px;
      width: 90px;
      height: 96px;
      line-height: 90px;
      text-align: center;
      background-color: transparent;
    }
  }

  h2 {
    font-size: 30px;
    color: #333;
    font-weight: 300;
  }

  h2 span {
    animation: anima 1s linear infinite;
  }

  h2 span:nth-child(1) {
    animation-delay: 0s;
  }

  h2 span:nth-child(2) {
    animation-delay: 0.4s;
  }

  @keyframes anima {

    0%,
    80% {
      color: #333;
      text-shadow: none;
    }

    100% {
      color: #9faa108f;
      text-shadow: 0 0 10px #d3263c8f,
        0 0 20px #f9f9f9,
        0 0 40px #9faa10,
        0 0 80px #9faa108f,
        0 0 120px #3e1c6a8f,
        0 0 160px #d3263c8f,
    }
  }
</style>
